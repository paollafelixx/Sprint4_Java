package be.com.neoporto.model.controller;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

import br.com.neoporto.model.beans.Solicitacao;
import br.com.neoporto.model.service.SolicitacaoService;

import java.util.List;


@Path("/solicitacoes")
public class SolicitacaoController {
	private SolicitacaoService solicitacaoService = new SolicitacaoService();

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Solicitacao> getAllSolicitacao() {
		return solicitacaoService.findAll();
	}

	@GET
	@Path("/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Solicitacao getSolicitacao(@PathParam("id") int id) {
		return solicitacaoService.findById(id);
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public void addSolicitacao(Solicitacao solicitacao) {
		solicitacaoService.save(solicitacao);
	}

	@PUT
	@Path("/{id}")
	@Consumes(MediaType.APPLICATION_JSON)
	public void updateSolicitacao(@PathParam("id") int id, Solicitacao solicitacao) {
		solicitacao.setId(id);
		solicitacaoService.update(solicitacao);
	}

	@DELETE
	@Path("/{id}")
	public void deleteSolicitacao(@PathParam("id") int id) {
		solicitacaoService.delete(id);
	}
}
