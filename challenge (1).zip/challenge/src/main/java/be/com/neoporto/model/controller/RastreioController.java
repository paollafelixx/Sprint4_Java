package be.com.neoporto.model.controller;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

import br.com.neoporto.model.beans.Rastreio;
import br.com.neoporto.model.service.RastreioService;

import java.util.List;


@Path("/rastreio")
public class RastreioController {
	private RastreioService rastreioService = new RastreioService();

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Rastreio> getAllRastreio() {
		return rastreioService.findAll();
	}

	@GET
	@Path("/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Rastreio getRastreio(@PathParam("id") int id) {
		return rastreioService.findById(id);
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public void addRastreio(Rastreio rastreio) {
		rastreioService.save(rastreio);
	}

	@PUT
	@Path("/{id}")
	@Consumes(MediaType.APPLICATION_JSON)
	public void updateRastreio(@PathParam("id") int id, Rastreio rastreio) {
		rastreio.setId(id);
		rastreioService.update(rastreio);
	}

	@DELETE
	@Path("/{id}")
	public void deleteRastreio(@PathParam("id") int id) {
		rastreioService.delete(id);
	}
}
