package be.com.neoporto.model.controller;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

import br.com.neoporto.model.beans.TipoVeiculo;
import br.com.neoporto.model.service.TipoVeiculoService;

import java.util.List;


@Path("/veiculos")
public class TipoVeiculoController {
	private TipoVeiculoService tipoVeiculoService = new TipoVeiculoService();

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<TipoVeiculo> getAllTipoVeiculo() {
		return tipoVeiculoService.findAll();
	}

	@GET
	@Path("/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public TipoVeiculo getTipoVeiculo(@PathParam("id") int id) {
		return tipoVeiculoService.findById(id);
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public void addTipoVeiculo(TipoVeiculo tipoVeiculo) {
		tipoVeiculoService.save(tipoVeiculo);
	}

	@PUT
	@Path("/{id}")
	@Consumes(MediaType.APPLICATION_JSON)
	public void updateTipoVeiculo(@PathParam("id") int id, TipoVeiculo tipoVeiculo) {
		tipoVeiculo.setId(id);
		tipoVeiculoService.update(tipoVeiculo);
	}

	@DELETE
	@Path("/{id}")
	public void deleteTipoVeiculo(@PathParam("id") int id) {
		tipoVeiculoService.delete(id);
	}
}
