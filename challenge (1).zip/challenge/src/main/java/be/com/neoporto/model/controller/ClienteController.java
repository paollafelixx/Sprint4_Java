package be.com.neoporto.model.controller;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import java.util.List;

import br.com.neoporto.model.beans.Cliente;
import br.com.neoporto.model.beans.GET;
import br.com.neoporto.model.beans.Path;
import br.com.neoporto.model.beans.PathParam;
import br.com.neoporto.model.beans.Produces;
import br.com.neoporto.model.service.ClienteService;

@Path("/clientes")
public class ClienteController {
	private ClienteService clienteService = new ClienteService();

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Cliente> getAllClientes() {
		return clienteService.findAll();
	}

	@GET
	@Path("/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Cliente getCliente(@PathParam("id") int id) {
		return clienteService.findById(id);
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public void addCliente(Cliente cliente) {
		clienteService.save(cliente);
	}

	@PUT
	@Path("/{id}")
	@Consumes(MediaType.APPLICATION_JSON)
	public void updateCliente(@PathParam("id") int id, Cliente cliente) {
		cliente.setId(id);
		clienteService.update(cliente);
	}

	@DELETE
	@Path("/{id}")
	public void deleteCliente(@PathParam("id") int id) {
		clienteService.delete(id);
	}
}
