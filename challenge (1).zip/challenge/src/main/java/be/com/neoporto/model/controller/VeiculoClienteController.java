package be.com.neoporto.model.controller;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

import br.com.neoporto.model.beans.VeiculoCliente;
import br.com.neoporto.model.service.VeiculoClienteService;

import java.util.List;


@Path("/veiculos clientes")
public class VeiculoClienteController {
	private VeiculoClienteService veiculoClienteService = new VeiculoClienteService();

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<VeiculoCliente> getAllVeiculoCliente() {
		return veiculoClienteService.findAll();
	}

	@GET
	@Path("/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public VeiculoCliente getVeiculoCliente(@PathParam("id") int id) {
		return veiculoClienteService.findById(id);
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public void addVeiculoCliente(VeiculoCliente veiculoCliente) {
		veiculoClienteService.save(veiculoCliente);
	}

	@PUT
	@Path("/{id}")
	@Consumes(MediaType.APPLICATION_JSON)
	public void updateVeiculoCliente(@PathParam("id") int id, VeiculoCliente veiculoCliente) {
		veiculoCliente.setId(id);
		veiculoClienteService.update(veiculoCliente);
	}

	@DELETE
	@Path("/{id}")
	public void deleteVeiculoCliente(@PathParam("id") int id) {
		veiculoClienteService.delete(id);
	}
}
