package be.com.neoporto.model.controller;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

import br.com.neoporto.model.beans.Contato;
import br.com.neoporto.model.service.ContatoService;

import java.util.List;

@Path("/contatos")
public class ContatoController {
	private ContatoService contatoService = new ContatoService();

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Contato> getAllContato() {
		return contatoService.findAll();
	}

	@GET
	@Path("/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Contato getContato(@PathParam("id") int id) {
		return contatoService.findById(id);
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public void addContato(Contato contato) {
		contatoService.save(contato);
	}

	@PUT
	@Path("/{id}")
	@Consumes(MediaType.APPLICATION_JSON)
	public void updateContato(@PathParam("id") int id, Contato contato) {
		contato.setId(id);
		contatoService.update(contato);
	}

	@DELETE
	@Path("/{id}")
	public void deleteContato(@PathParam("id") int id) {
		contatoService.delete(id);
	}
}
