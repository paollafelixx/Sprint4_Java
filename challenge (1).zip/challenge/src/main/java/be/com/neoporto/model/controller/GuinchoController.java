package be.com.neoporto.model.controller;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

import br.com.neoporto.model.beans.Guincho;
import br.com.neoporto.model.service.GuinchoService;

import java.util.List;



@Path("/guinchos")
public class GuinchoController {
	private GuinchoService guinchoService = new GuinchoService();

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Guincho> getAllClientes() {
		return guinchoService.findAll();
	}

	@GET
	@Path("/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Guincho getGuincho(@PathParam("id") int id) {
		return guinchoService.findById(id);
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public void addGuincho(Guincho guincho) {
		guinchoService.save(guincho);
	}

	@PUT
	@Path("/{id}")
	@Consumes(MediaType.APPLICATION_JSON)
	public void updateGuincho(@PathParam("id") int id, Guincho guincho) {
		guincho.setId(id);
		guinchoService.update(guincho);
	}

	@DELETE
	@Path("/{id}")
	public void deleteGuincho(@PathParam("id") int id) {
		guinchoService.delete(id);
	}
}
