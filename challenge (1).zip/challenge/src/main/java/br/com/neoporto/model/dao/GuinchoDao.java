package br.com.neoporto.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.neoporto.connection.ConnectionFactory;
import br.com.neoporto.model.beans.Guincho;

public class GuinchoDao {
    public Guincho buscarGuinchoPorId(int id) {
        String sql = "SELECT * FROM guincho WHERE id = ?";
        Guincho guincho = null;

        try (Connection connection = ConnectionFactory.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, id);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
              
                    guincho = new Guincho(sql, sql, id, id, id, id);
                    guincho.setId(resultSet.getInt("id"));
                    guincho.setTipoGuincho(resultSet.getString("tipo"));
                    guincho.setPlacaGuincho(resultSet.getString("placa"));
                  
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao executar opera��o de localizar o guincho.", e);
        }

        return guincho;
    }


    public List<Guincho> buscarTodosGuinchos() {
        String sql = "SELECT * FROM guincho";
        List<Guincho> guinchos = new ArrayList<>();

        try (Connection connection = ConnectionFactory.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                Guincho guincho = new Guincho(sql, sql, 0, 0, 0, 0);
                guincho.setId(resultSet.getInt("id"));
                guincho.setTipoGuincho(resultSet.getString("tipo"));
                guincho.setPlacaGuincho(resultSet.getString("placa"));
                guinchos.add(guincho);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao executar opera��o de localizar todos os guinchos", e);
        }

        return guinchos;
    }


    public void salvarGuincho(Guincho guincho) {
        String sql = "INSERT INTO guincho (tipo, placa) VALUES (?, ?)";

        try (Connection connection = ConnectionFactory.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, guincho.getTipoGuincho());
            statement.setString(2, guincho.getPlacaGuincho());
            statement.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao executar opera��o de salvar informa��o do guincho.", e);
        }
    }

    public void atualizarGuincho(Guincho guincho) {
        String sql = "UPDATE guincho SET nome = ?, cpf = ? WHERE id = ?";

        try (Connection connection = ConnectionFactory.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, guincho.getTipoGuincho());
            statement.setString(2, guincho.getPlacaGuincho());
            statement.setInt(3, guincho.getId());

            int linhasAfetadas = statement.executeUpdate();

            if (linhasAfetadas == 0) {
                throw new RuntimeException("Guincho n�o encontrado para atualiza��o.");
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao executar opera��o de atualiza��o.", e);
        }
    }

    public void deletarGuincho(int guinchoId) {
        String sql = "DELETE FROM guincho WHERE id = ?";

        try (Connection connection = ConnectionFactory.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, guinchoId);

            int linhasAfetadas = statement.executeUpdate();

            if (linhasAfetadas == 0) {
                throw new RuntimeException("Guincho n�o encontrado para exclus�o.");
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao executar opera��o de exclus�o.", e);
        }
    }
}
