package br.com.neoporto.model.beans;

public @interface PathParam {

	String value();

}
