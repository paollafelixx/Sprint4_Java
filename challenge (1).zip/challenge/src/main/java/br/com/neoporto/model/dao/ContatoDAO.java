package br.com.neoporto.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.neoporto.connection.ConnectionFactory;
import br.com.neoporto.model.beans.Contato;

public class ContatoDAO {
	public Contato buscarContatoPorId(int contatoId) {
        String sql = "SELECT * FROM contato WHERE id = ?";
        Contato contato = null;

        try (Connection connection = ConnectionFactory.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, contatoId);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    contato = new Contato(contatoId, sql, contatoId);
                    contato.setId(resultSet.getInt("id"));
                    contato.setNome(resultSet.getString("nome"));
                    contato.setTelefone(resultSet.getString("telefone"));
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao executar opera��o de localizar contato.", e);
        }

        return contato;
    }

	public List<Contato> buscarTodosContatos() {
        String sql = "SELECT * FROM contato";
        List<Contato> clientes = new ArrayList<>();

        try (Connection connection = ConnectionFactory.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
            	Contato contato = new Contato(0, sql, 0);
            	contato.setId(resultSet.getInt("id"));
            	contato.setNome(resultSet.getString("nome"));
            	contato.setCpf(resultSet.getString("cpf"));
                

                clientes.add(contato);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao executar opera��o localizar todos os contatos.", e);
        }

        return clientes;
    }


    public void salvarContato(Contato contato) {
        String sql = "INSERT INTO contato (nome, telefone) VALUES (?, ?)";

        try (Connection connection = ConnectionFactory.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, contato.getId());
            statement.setInt(2, contato.getTelefone());
            statement.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao executar opera��o no banco de dados", e);
        }
    }	

    public void atualizarContato(Contato contato) {
        String sql = "UPDATE contato SET nome = ?, cpf = ? WHERE id = ?";

        try (Connection connection = ConnectionFactory.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

        	 statement.setInt(1, contato.getId());
             statement.setInt(2, contato.getTelefone());

            int linhasAfetadas = statement.executeUpdate();

            if (linhasAfetadas == 0) {
                throw new RuntimeException("Contato n�o encontrado para atualiza��o.");
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao executar opera��o de atualiza��o.", e);
        }
    }

    public void deletarContato(int contatoId) {
        String sql = "DELETE FROM contato WHERE id = ?";

        try (Connection connection = ConnectionFactory.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, contatoId);

            int linhasAfetadas = statement.executeUpdate();

            if (linhasAfetadas == 0) {
                throw new RuntimeException("Contato n�o encontrado para exclus�o.");
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao executar opera��o de exclus�o.", e);
        }
    }
}
