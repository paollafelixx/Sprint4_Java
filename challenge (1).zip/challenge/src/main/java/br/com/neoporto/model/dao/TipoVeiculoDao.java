package br.com.neoporto.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.neoporto.connection.ConnectionFactory;
import br.com.neoporto.model.beans.Cliente;
import br.com.neoporto.model.beans.TipoVeiculo;

public class TipoVeiculoDao {
	public TipoVeiculo buscarTipoVeiculoPorId(int id) {
        String sql = "SELECT * FROM tipoVeiculo WHERE id = ?";
        TipoVeiculo tipoVeiculo = null;

        try (Connection connection = ConnectionFactory.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, id);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
              
                	tipoVeiculo = new TipoVeiculo(id, sql, id, id, sql, sql, sql, id, id, id);
                	tipoVeiculo.setId(resultSet.getInt("id"));
                    tipoVeiculo.setTipoVeiculo(resultSet.getString("tipoVeiculo"));
                                     
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao executar opera��o de localizar o tipo do veiculo.", e);
        }

        return tipoVeiculo;
    }

	public List<TipoVeiculo> buscarTodosTipoVeiculo() {
        String sql = "SELECT * FROM cliente";
        List<TipoVeiculo> tipoVeiculo = new ArrayList<>();

        try (Connection connection = ConnectionFactory.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
            	TipoVeiculo tipoVeiculo1 = new TipoVeiculo(0, sql, 0, 0, sql, sql, sql, 0, 0, 0);
            	tipoVeiculo1.setId(resultSet.getInt("id"));
            	              

            	tipoVeiculo1.add(tipoVeiculo1);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao executar opera��o localizar todos os tipo de veiculo.", e);
        }

        return tipoVeiculo;
    }

    public void salvarTipoVeiculo(TipoVeiculo tipoVeiculo) {
        String sql = "INSERT INTO rastreio (tipo, peso) VALUES (?, ?)";

        try (Connection connection = ConnectionFactory.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, tipoVeiculo.getTipoVeiculo());
            statement.setFloat(2, tipoVeiculo.getPeso());
            statement.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao executar opera��o no banco de dados", e);
        }
    }

    public void atualizarTipoVeiculo(TipoVeiculo tipoVeiculo) {
        String sql = "UPDATE tipoVeiculo SET tipo = ?, placa = ? WHERE id = ?";

        try (Connection connection = ConnectionFactory.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, tipoVeiculo.getTipoVeiculo());
            statement.setString(2, tipoVeiculo.getPlacaVeiculo());
            statement.setInt(3, tipoVeiculo.getId());

            int linhasAfetadas = statement.executeUpdate();

            if (linhasAfetadas == 0) {
                throw new RuntimeException("Tipo Veiculo n�o encontrado para atualiza��o.");
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao executar opera��o de atualiza��o.", e);
        }
    }

    public void deletarTipoVeiculo(int tipoVeiculoId) {
        String sql = "DELETE FROM tipoVeiculo WHERE id = ?";

        try (Connection connection = ConnectionFactory.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, tipoVeiculoId);

            int linhasAfetadas = statement.executeUpdate();

            if (linhasAfetadas == 0) {
                throw new RuntimeException("Tipo veiculo n�o encontrado para exclus�o.");
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao executar opera��o de exclus�o.", e);
        }
    }
}
