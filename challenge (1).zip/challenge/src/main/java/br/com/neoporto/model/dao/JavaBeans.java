package br.com.neoporto.model.dao;

public class JavaBeans {
	
	

}
