package br.com.neoporto.model.service;

import java.util.List;

import br.com.neoporto.model.beans.Guincho;
import br.com.neoporto.model.dao.GuinchoDao;

public class GuinchoService {
    private GuinchoDao guinchoDao = new GuinchoDao();

    public Guincho findById(int guinchoId) {
        if (guinchoId <= 0) {
            throw new IllegalArgumentException("ID do guincho deve ser um n�mero positivo.");
        }

        return guinchoDao.buscarGuinchoPorId(guinchoId);
    }

    public List<Guincho> findAll() {
        return guinchoDao.buscarTodosGuinchos();
    }

    @SuppressWarnings("unchecked")
	public void save(Guincho guincho) {
        if (guincho == null || guincho.getMarca() == null || ((List<Guincho>) guincho.getMarca()).isEmpty()) {
            throw new IllegalArgumentException("Marca do guincho � obrigat�ria.");
        }

        guinchoDao.salvarGuincho(guincho);
    }

    public void update(Guincho guincho) {
        if (guincho == null || guincho.getId() <= 0) {
            throw new IllegalArgumentException("Guincho inv�lido para atualiza��o.");
        }

        guinchoDao.atualizarGuincho(guincho);
    }

    public void delete(int guinchoId) {
        if (guinchoId <= 0) {
            throw new IllegalArgumentException("ID do guincho deve ser um n�mero positivo.");
        }

        guinchoDao.deletarGuincho(guinchoId);
    }
}
