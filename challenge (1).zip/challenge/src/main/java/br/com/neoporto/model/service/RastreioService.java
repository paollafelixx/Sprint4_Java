package br.com.neoporto.model.service;

import java.util.List;

import br.com.neoporto.model.beans.Rastreio;
import br.com.neoporto.model.dao.RastreioDao;

public class RastreioService {
    private RastreioDao rastreioDao = new RastreioDao();

    public Rastreio findById(int rastreioId) {
        if (rastreioId <= 0) {
            throw new IllegalArgumentException("ID do rastreio deve ser um n�mero positivo.");
        }

        return rastreioDao.buscarRastreioPorId(rastreioId);
    }

    public List<Rastreio> findAll() {
        return rastreioDao.buscarTodosRastreios();
    }

    @SuppressWarnings("unchecked")
	public void save(Rastreio rastreio) {
        if (rastreio == null || rastreio.getCodigo() == null || ((List<Rastreio>) rastreio.getCodigo()).isEmpty()) {
            throw new IllegalArgumentException("C�digo do rastreio � obrigat�rio.");
        }

        rastreioDao.salvarRastreio(rastreio);
    }

    public void update(Rastreio rastreio) {
        if (rastreio == null || rastreio.getId() <= 0) {
            throw new IllegalArgumentException("Rastreio inv�lido para atualiza��o.");
        }

        rastreioDao.atualizarRastreio(rastreio);
    }

    public void delete(int rastreioId) {
        if (rastreioId <= 0) {
            throw new IllegalArgumentException("ID do rastreio deve ser um n�mero positivo.");
        }

        rastreioDao.deletarRastreio(rastreioId);
    }
}

