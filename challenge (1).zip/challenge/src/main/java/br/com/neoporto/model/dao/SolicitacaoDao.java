package br.com.neoporto.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.neoporto.connection.ConnectionFactory;
import br.com.neoporto.model.beans.Cliente;
import br.com.neoporto.model.beans.Solicitacao;

public class SolicitacaoDao {
	public Solicitacao buscarSolicitacaoPorId(int id) {
        String sql = "SELECT * FROM solicitacao WHERE id = ?";
        Solicitacao solicitacao = null;

        try (Connection connection = ConnectionFactory.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, id);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
              
                	solicitacao = new Solicitacao(null, null, null, null, null);
                	solicitacao.setId(resultSet.getInt("id"));
                	
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao executar opera��o.", e);
        }

        return solicitacao;
    }

	public List<Solicitacao> buscarTodasSolicitacoes() {
        String sql = "SELECT * FROM cliente";
        List<Solicitacao> solicitacao = new ArrayList<>();

        try (Connection connection = ConnectionFactory.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
            	Solicitacao solicitacao1 = new Solicitacao(null, null, null, null, null);
            	solicitacao1.setId(resultSet.getInt("id"));
            	
                

                solicitacao1.add(solicitacao1);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao executar opera��o localizar todos os clientes.", e);
        }

        return solicitacao;
    }

	public void salvarSolicitacao(Solicitacao solicitacao) {
        String sql = "INSERT INTO solicitacao (id) VALUES (?, ?)";

        try (Connection connection = ConnectionFactory.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, solicitacao.getId());
            statement.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao executar opera��o de salvar.", e);
        }
    }

	public void atualizarSolicitacao(Solicitacao solicitacao) {
        String sql = "UPDATE solicitacao SET id = ?, ordem = ? WHERE id = ?";

        try (Connection connection = ConnectionFactory.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, solicitacao.getId());
           ;

            int linhasAfetadas = statement.executeUpdate();

            if (linhasAfetadas == 0) {
                throw new RuntimeException("Solicitacao n�o encontrado para atualiza��o.");
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao executar opera��o de atualiza��o.", e);
        }
    }

    public void deletarSolicitacao(int solicitacaoId) {
        String sql = "DELETE FROM solicitacao WHERE id = ?";

        try (Connection connection = ConnectionFactory.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, solicitacaoId);

            int linhasAfetadas = statement.executeUpdate();

            if (linhasAfetadas == 0) {
                throw new RuntimeException("Solicitacao n�o encontrado para exclus�o.");
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao executar opera��o de exclus�o.", e);
        }
    }
}
