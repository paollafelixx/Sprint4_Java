package br.com.neoporto.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.neoporto.connection.ConnectionFactory;
import br.com.neoporto.model.beans.Cliente;
import br.com.neoporto.model.beans.VeiculoCliente;

public class VeiculoClienteDao {
	public VeiculoCliente buscarVeiculoClientePorId(int id) {
        String sql = "SELECT * FROM veiculoCliente WHERE id = ?";
        VeiculoCliente veiculoCliente = null;

        try (Connection connection = ConnectionFactory.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, id);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
              
                	veiculoCliente = new VeiculoCliente();
                	veiculoCliente.setId(resultSet.getInt("id"));      
                  
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao executar opera��o de localizar o veiculo do clientes.", e);
        }

        return veiculoCliente;
    }

	public List<VeiculoCliente> buscarTodosVeiculoCliente() {
        String sql = "SELECT * FROM veiculoClientes";
        List<VeiculoCliente> veiculoClientes = new ArrayList<>();

        try (Connection connection = ConnectionFactory.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
            	VeiculoCliente veiculoClientes1 = new VeiculoCliente(0, 0, 0, 0, sql, sql, sql, 0, 0, 0, sql, sql);
            	veiculoClientes1.setId(resultSet.getInt("id"));
            	

            	veiculoClientes1.add(veiculoClientes1);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao executar opera��o localizar todos os veiculo de clientes.", e);
        }

        return veiculoClientes;
    }

    public void salvarVeiculoCliente(VeiculoCliente veiculoCliente) {
        String sql = "INSERT INTO rastreio (tipo, chassi) VALUES (?, ?)";

        try (Connection connection = ConnectionFactory.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, veiculoCliente.getTipoVeiculo());
            statement.setString(2, veiculoCliente.getChassi());
            statement.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao executar opera��o no banco de dados", e);
        }
    }

    public void atualizarVeiculoCliente(VeiculoCliente veiculoCliente) {
        String sql = "UPDATE veiculoCliente SET tipo = ?, placa = ? WHERE id = ?";

        try (Connection connection = ConnectionFactory.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, veiculoCliente.getTipoVeiculo());
            statement.setString(2, veiculoCliente.getPlacaVeiculo());
            statement.setInt(3, veiculoCliente.getId());

            int linhasAfetadas = statement.executeUpdate();

            if (linhasAfetadas == 0) {
                throw new RuntimeException("Veiculo n�o encontrado para atualiza��o.");
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao executar opera��o de atualiza��o.", e);
        }
    }

    public void deletarVeiculoCliente(int veiculoClienteId) {
        String sql = "DELETE FROM veiculoCliente WHERE id = ?";

        try (Connection connection = ConnectionFactory.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, veiculoClienteId);

            int linhasAfetadas = statement.executeUpdate();

            if (linhasAfetadas == 0) {
                throw new RuntimeException("Veiculo n�o encontrado para exclus�o.");
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao executar opera��o de exclus�o.", e);
        }
    }
}
