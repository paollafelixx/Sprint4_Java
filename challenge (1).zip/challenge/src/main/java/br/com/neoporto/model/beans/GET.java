package br.com.neoporto.model.beans;

public @interface GET {

}
