package br.com.neoporto.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.neoporto.connection.ConnectionFactory;
import br.com.neoporto.model.beans.Rastreio;


public class RastreioDao {
	public Rastreio buscarRastreioPorId(int id) {
        String sql = "SELECT * FROM rastreio WHERE id = ?";
        Rastreio rastreio = null;

        try (Connection connection = ConnectionFactory.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, id);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
              
                	rastreio = new Rastreio(id, id, sql, id, id, sql);
                	rastreio.setId(resultSet.getInt("id rastreio"));
                	rastreio.setOrdemServico(resultSet.getInt("ordem"));
                	rastreio.setIdOperador(resultSet.getInt("id operador"));
                  
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao executar opera��o de localizar o rastreio.", e);
        }

        return rastreio;
    }

	public List<Rastreio> buscarTodosRastreios() {
        String sql = "SELECT * FROM rastreio";
        List<Rastreio> rastreio = new ArrayList<>();

        try (Connection connection = ConnectionFactory.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
            	Rastreio rastreio1 = new Rastreio(0, 0, sql, 0, 0, sql);
            	rastreio1.setId(resultSet.getInt("id rastreio"));
            	rastreio1.setOrdemServico(resultSet.getInt("ordem"));
            	rastreio1.setIdOperador(resultSet.getInt("id operador"));
                

                rastreio1.add(rastreio1);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao executar opera��o localizar todos os rastreios.", e);
        }

        
		return rastreio;
    }


    public void salvarRastreio(Rastreio rastreio) {
        String sql = "INSERT INTO rastreio (ordem, operador) VALUES (?, ?)";

        try (Connection connection = ConnectionFactory.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, rastreio.getOrdemServico());
            statement.setInt(2, rastreio.getIdOperador());
            statement.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao executar opera��o de salvar rastreio.", e);
        }
    }

    public void atualizarRastreio(Rastreio rastreio) {
        String sql = "UPDATE rastreio SET ordem = ?, operador = ? WHERE id = ?";

        try (Connection connection = ConnectionFactory.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, rastreio.getOrdemServico());
            statement.setInt(2, rastreio.getIdOperador());
            statement.setInt(3, rastreio.getId());

            int linhasAfetadas = statement.executeUpdate();

            if (linhasAfetadas == 0) {
                throw new RuntimeException("Rastreio n�o encontrado para atualiza��o");
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao executar opera��o no banco de dados", e);
        }
    }

    public void deletarRastreio(int rastreioId) {
        String sql = "DELETE FROM rastreio WHERE id = ?";

        try (Connection connection = ConnectionFactory.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, rastreioId);

            int linhasAfetadas = statement.executeUpdate();

            if (linhasAfetadas == 0) {
                throw new RuntimeException("Rastreio n�o encontrado para exclus�o.");
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao executar opera��o de exclus�o.", e);
        }
    }
}
