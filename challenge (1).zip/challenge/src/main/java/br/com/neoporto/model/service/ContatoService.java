package br.com.neoporto.model.service;

import java.util.List;

import br.com.neoporto.model.beans.Contato;
import br.com.neoporto.model.dao.ContatoDAO;

public class ContatoService {
    private ContatoDAO contatoDao = new ContatoDAO();

    public Contato findById(int contatoId) {
        if (contatoId <= 0) {
            throw new IllegalArgumentException("ID do contato deve ser um n�mero positivo.");
        }

        return contatoDao.buscarContatoPorId(contatoId);
    }

    public List<Contato> findAll() {
        return contatoDao.buscarTodosContatos();
    }
    
    @SuppressWarnings("unchecked")
	public void save(Contato contato) {
        if (contato == null || contato.getNome() == null || ((List<Contato>) contato.getNome()).isEmpty()) {
            throw new IllegalArgumentException("Nome do contato � obrigat�rio.");
        }

        contatoDao.salvarContato(contato);
    }

    public void update(Contato contato) {
        if (contato == null || contato.getId() <= 0) {
            throw new IllegalArgumentException("Contato inv�lido para atualiza��o.");
        }

        contatoDao.atualizarContato(contato);
    }
    
    public void delete(int contatoId) {
        if (contatoId <= 0) {
            throw new IllegalArgumentException("ID do contato deve ser um n�mero positivo.");
        }

        contatoDao.deletarContato(contatoId);
    }
}

