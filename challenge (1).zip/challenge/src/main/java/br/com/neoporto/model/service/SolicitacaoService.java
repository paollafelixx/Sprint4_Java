package br.com.neoporto.model.service;

import java.util.List;

import br.com.neoporto.model.beans.Solicitacao;
import br.com.neoporto.model.dao.SolicitacaoDao;

public class SolicitacaoService {

    private final SolicitacaoDao solicitacaoDao;

    public SolicitacaoService(SolicitacaoDao solicitacaoDao) {
        this.solicitacaoDao = solicitacaoDao;
    }

    public Solicitacao findById(int solicitacaoId) {
        if (solicitacaoId <= 0) {
            throw new IllegalArgumentException("ID da solicita��o deve ser um n�mero positivo.");
        }

        return solicitacaoDao.buscarSolicitacaoPorId(solicitacaoId);
    }

    public List<Solicitacao> findAll() {
        return solicitacaoDao.buscarTodasSolicitacoes();
    }

    public void save(Solicitacao solicitacao) {
        if (solicitacao == null || solicitacao.getDescricao() == null || solicitacao.getDescricao().isEmpty()) {
            throw new IllegalArgumentException("Descri��o da solicita��o � obrigat�ria.");
        }

        solicitacaoDao.salvarSolicitacao(solicitacao);
    }

    public void update(Solicitacao solicitacao) {
        if (solicitacao == null || solicitacao.getId() <= 0) {
            throw new IllegalArgumentException("Solicita��o inv�lida para atualiza��o.");
        }

        solicitacaoDao.atualizarSolicitacao(solicitacao);
    }

    public void delete(int solicitacaoId) {
        if (solicitacaoId <= 0) {
            throw new IllegalArgumentException("ID da solicita��o deve ser um n�mero positivo.");
        }

        solicitacaoDao.deletarSolicitacao(solicitacaoId);
    }
}
