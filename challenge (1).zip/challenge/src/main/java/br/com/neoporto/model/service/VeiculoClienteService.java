package br.com.neoporto.model.service;

import java.util.List;

import br.com.neoporto.model.beans.VeiculoCliente;
import br.com.neoporto.model.dao.VeiculoClienteDao;

public class VeiculoClienteService {
    private VeiculoClienteDao veiculoClienteDao = new VeiculoClienteDao();

    public VeiculoCliente findById(int veiculoClienteId) {
        if (veiculoClienteId <= 0) {
            throw new IllegalArgumentException("ID do ve�culo do cliente deve ser um n�mero positivo.");
        }

        return veiculoClienteDao.buscarVeiculoClientePorId(veiculoClienteId);
    }

    public List<VeiculoCliente> findAll() {
        return veiculoClienteDao.buscarTodosVeiculoCliente();
    }

    public void save(VeiculoCliente veiculoCliente) {
        if (veiculoCliente == null || veiculoCliente.getPlacaGuincho() == null || veiculoCliente.getPlacaGuincho().isEmpty()) {
            throw new IllegalArgumentException("Placa do ve�culo do cliente � obrigat�ria.");
        }

        veiculoClienteDao.salvarVeiculoCliente(veiculoCliente);
    }

    public void update(VeiculoCliente veiculoCliente) {
        if (veiculoCliente == null || veiculoCliente.getId() <= 0) {
            throw new IllegalArgumentException("Ve�culo do cliente inv�lido para atualiza��o.");
        }

        veiculoClienteDao.atualizarVeiculoCliente(veiculoCliente);
    }

    public void delete(int veiculoClienteId) {
        if (veiculoClienteId <= 0) {
            throw new IllegalArgumentException("ID do ve�culo do cliente deve ser um n�mero positivo.");
        }

        veiculoClienteDao.deletarVeiculoCliente(veiculoClienteId);
    }
}

