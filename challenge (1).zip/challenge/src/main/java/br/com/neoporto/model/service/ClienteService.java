package br.com.neoporto.model.service;
import java.util.List;

import br.com.neoporto.model.beans.Cliente;
import br.com.neoporto.model.dao.ClienteDao;

public class ClienteService {

    private ClienteDao clienteDao;
    

    public ClienteService(ClienteDao clienteDao) {
        this.clienteDao = clienteDao;
    }

    public Cliente findById(int clienteId) {
        
        if (clienteId <= 0) {
            throw new IllegalArgumentException("ID do cliente deve ser um n�mero positivo.");
        }

       
        return clienteDao.buscarClientePorId(clienteId);
    }

    public List<Cliente> findAll() {
        
        return clienteDao.buscarTodosClientes();
    }

    public void save(Cliente cliente) {
        if (cliente == null || cliente.getNome() == null || cliente.getNome().isEmpty()) {
            throw new IllegalArgumentException("Nome do cliente � obrigat�rio.");
        }

        clienteDao.salvarCliente(cliente);
    }

    public void update(Cliente cliente) {
        if (cliente == null || cliente.getId() <= 0) {
            throw new IllegalArgumentException("Cliente inv�lido para atualiza��o.");
        }

        clienteDao.atualizarCliente(cliente);
    }

    public void delete(int clienteId) {
        if (clienteId <= 0) {
            throw new IllegalArgumentException("ID do cliente deve ser um n�mero positivo.");
        }

        clienteDao.deletarCliente(clienteId);
    }
}
