package br.com.neoporto.model.service;

import java.util.List;

import br.com.neoporto.model.beans.TipoVeiculo;
import br.com.neoporto.model.dao.TipoVeiculoDao;

public class TipoVeiculoService {
    private TipoVeiculoDao tipoVeiculoDao = new TipoVeiculoDao();

    public TipoVeiculo findById(int tipoVeiculoId) {
        if (tipoVeiculoId <= 0) {
            throw new IllegalArgumentException("ID do tipo de ve�culo deve ser um n�mero positivo.");
        }

        return tipoVeiculoDao.buscarTipoVeiculoPorId(tipoVeiculoId);
    }

    public List<TipoVeiculo> findAll() {
        return tipoVeiculoDao.buscarTodosTipoVeiculo();
    }

    public void save(TipoVeiculo tipoVeiculo) {
        if (tipoVeiculo == null || tipoVeiculo.getNome() == null || tipoVeiculo.getNome().isEmpty()) {
            throw new IllegalArgumentException("Nome do tipo de ve�culo � obrigat�rio.");
        }

        tipoVeiculoDao.salvarTipoVeiculo(tipoVeiculo);
    }

    public void update(TipoVeiculo tipoVeiculo) {
        if (tipoVeiculo == null || tipoVeiculo.getId() <= 0) {
            throw new IllegalArgumentException("Tipo de ve�culo inv�lido para atualiza��o.");
        }

        tipoVeiculoDao.atualizarTipoVeiculo(tipoVeiculo);
    }

    public void delete(int tipoVeiculoId) {
        if (tipoVeiculoId <= 0) {
            throw new IllegalArgumentException("ID do tipo de ve�culo deve ser um n�mero positivo.");
        }

        tipoVeiculoDao.deletarTipoVeiculo(tipoVeiculoId);
    }
}

