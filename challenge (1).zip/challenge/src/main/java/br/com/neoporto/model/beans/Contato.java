package br.com.neoporto.model.beans;

public class Contato {
	
	private int id;
	private String cpf;
	private int telefone;
	
	public Contato(int id, String cpf, int telefone) {
		super();
		this.id = id;
		this.cpf = cpf;
		this.telefone = telefone;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String string) {
		this.cpf = string;
	}

	public int getTelefone() {
		return telefone;
	}

	public void setTelefone(String string) {
		this.telefone = string;
	}

	public void setNome(String string) {
		// TODO Auto-generated method stub
		
	}

	public Object getNome() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	

}
