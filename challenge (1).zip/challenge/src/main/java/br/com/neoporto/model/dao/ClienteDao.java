package br.com.neoporto.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.neoporto.connection.ConnectionFactory;
import br.com.neoporto.model.beans.Cliente;

public class ClienteDao {
    public Cliente buscarClientePorId(int id) {
            String sql = "SELECT * FROM cliente WHERE id = ?";
            Cliente cliente = null;

            try (Connection connection = ConnectionFactory.getConnection();
                 PreparedStatement statement = connection.prepareStatement(sql)) {

                statement.setInt(1, id);

                try (ResultSet resultSet = statement.executeQuery()) {
                    if (resultSet.next()) {
                  
                        cliente = new Cliente(id, sql, id, id, sql, sql);
                        cliente.setId(resultSet.getInt("id"));
                        cliente.setNome(resultSet.getString("nome"));
                        cliente.setCpf(resultSet.getString("cpf"));
                      
                    }
                }

            } catch (SQLException e) {
                throw new RuntimeException("Erro ao executar opera��o de localizar o cliente.", e);
            }

            return cliente;
        }
    

    public List<Cliente> buscarTodosClientes() {
        String sql = "SELECT * FROM cliente";
        List<Cliente> clientes = new ArrayList<>();

        try (Connection connection = ConnectionFactory.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                Cliente cliente = new Cliente(0, sql, 0, 0, sql, sql);
                cliente.setId(resultSet.getInt("id"));
                cliente.setNome(resultSet.getString("nome"));
                cliente.setCpf(resultSet.getString("cpf"));
                

                clientes.add(cliente);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao executar opera��o localizar todos os clientes.", e);
        }

        return clientes;
    }

    public void salvarCliente(Cliente cliente) {
        String sql = "INSERT INTO cliente (nome, cpf) VALUES (?, ?)";

        try (Connection connection = ConnectionFactory.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, cliente.getNome());
            statement.setString(2, cliente.getCpf());
            statement.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao executar opera��o de salvar.", e);
        }
    }

    public void atualizarCliente(Cliente cliente) {
        String sql = "UPDATE cliente SET nome = ?, cpf = ? WHERE id = ?";

        try (Connection connection = ConnectionFactory.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, cliente.getNome());
            statement.setString(2, cliente.getCpf());
            statement.setInt(3, cliente.getId());

            int linhasAfetadas = statement.executeUpdate();

            if (linhasAfetadas == 0) {
                throw new RuntimeException("Cliente n�o encontrado para atualiza��o.");
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao executar opera��o de atualiza��o.", e);
        }
    }

    public void deletarCliente(int clienteId) {
        String sql = "DELETE FROM cliente WHERE id = ?";

        try (Connection connection = ConnectionFactory.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, clienteId);

            int linhasAfetadas = statement.executeUpdate();

            if (linhasAfetadas == 0) {
                throw new RuntimeException("Cliente n�o encontrado para exclus�o.");
            }

        } catch (SQLException e) {
            throw new RuntimeException("Erro ao executar opera��o de exclus�o.", e);
        }
    }
}
